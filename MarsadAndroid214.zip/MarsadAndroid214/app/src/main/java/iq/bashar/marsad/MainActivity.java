package iq.bashar.marsad;

import android.app.*;
import android.os.*;
import android.content.*;
import android.graphics.Color;
import android.net.Uri;
import android.print.*;
import android.util.Base64;
import android.view.*;
import android.webkit.*;
import android.widget.*;
import java.io.OutputStream;

public class MainActivity extends Activity {
    private static final String DEFAULT_CLOUD = "https://marsad.bashar-q-zalzala.workers.dev";
    private WebView web;
    private LinearLayout root;
    private ValueCallback<Uri[]> chooser;
    private byte[] pendingFile;
    private String mode = "cloud";

    private android.content.SharedPreferences prefs() {
        return getSharedPreferences("marsad-mobile", MODE_PRIVATE);
    }

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        mode = prefs().getString("mode", "cloud");
        buildUi();
        String url = currentOrigin();
        if (url.isEmpty()) configure();
        else web.loadUrl(url + "/");
    }

    private void buildUi() {
        root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(Color.rgb(238,243,248));
        setContentView(root);

        LinearLayout bar = new LinearLayout(this);
        bar.setOrientation(LinearLayout.HORIZONTAL);
        bar.setPadding(8,8,8,8);

        Button cloud = new Button(this); cloud.setText("سحابي");
        Button lan = new Button(this); lan.setText("داخل الدائرة");
        Button settings = new Button(this); settings.setText("الإعداد");

        cloud.setOnClickListener(v -> switchMode("cloud"));
        lan.setOnClickListener(v -> switchMode("lan"));
        settings.setOnClickListener(v -> configure());

        bar.addView(cloud, new LinearLayout.LayoutParams(0,-2,1));
        bar.addView(lan, new LinearLayout.LayoutParams(0,-2,1));
        bar.addView(settings, new LinearLayout.LayoutParams(0,-2,1));
        root.addView(bar);

        web = new WebView(this);
        root.addView(web, new LinearLayout.LayoutParams(-1,0,1));
        configureWeb(web);
    }

    private void switchMode(String newMode) {
        mode = newMode;
        prefs().edit().putString("mode", mode).apply();
        String url = currentOrigin();
        if (url.isEmpty()) configure();
        else web.loadUrl(url + "/");
    }

    private String currentOrigin() {
        return prefs().getString(mode.equals("lan") ? "lan_url" : "cloud_url", mode.equals("cloud") ? DEFAULT_CLOUD : "");
    }

    private String normalize(String raw) throws Exception {
        String v = raw.trim();
        Uri u = Uri.parse(v);
        if (!"https".equalsIgnoreCase(u.getScheme()) || u.getHost()==null || u.getUserInfo()!=null)
            throw new Exception("HTTPS required");
        String authority = u.getEncodedAuthority();
        return "https://" + authority;
    }

    private void configure() {
        EditText cloud = new EditText(this);
        cloud.setHint("https://رابط-مرصد-السحابي");
        cloud.setSingleLine();
        cloud.setText(prefs().getString("cloud_url",DEFAULT_CLOUD));

        EditText lan = new EditText(this);
        lan.setHint("https://marsad.office:8765");
        lan.setSingleLine();
        lan.setText(prefs().getString("lan_url",""));

        LinearLayout pane = new LinearLayout(this);
        pane.setOrientation(LinearLayout.VERTICAL);
        pane.setPadding(32,16,32,8);
        TextView help = new TextView(this);
        help.setText("مرصد المشاريع 2.1.14\nيمكنك استعمال النسخة السحابية من أي إنترنت، أو خادم الدائرة عبر LAN.\nكل الروابط يجب أن تكون HTTPS.");
        pane.addView(help);
        pane.addView(cloud);
        pane.addView(lan);

        new AlertDialog.Builder(this)
            .setTitle("إعداد اتصال مرصد")
            .setView(pane)
            .setPositiveButton("حفظ", (d,x) -> {
                try {
                    String c = cloud.getText().toString().trim();
                    String l = lan.getText().toString().trim();
                    if (!c.isEmpty()) c = normalize(c);
                    if (!l.isEmpty()) l = normalize(l);
                    prefs().edit().putString("cloud_url",c).putString("lan_url",l).apply();
                    String target = currentOrigin();
                    if (!target.isEmpty()) web.loadUrl(target + "/");
                } catch(Exception e) {
                    Toast.makeText(this,"العنوان يجب أن يكون HTTPS صحيح",Toast.LENGTH_LONG).show();
                }
            })
            .setNegativeButton("إلغاء", null)
            .show();
    }

    private void configureWeb(WebView w) {
        WebSettings s = w.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setDatabaseEnabled(true);
        s.setAllowFileAccess(false);
        s.setAllowContentAccess(false);
        s.setMixedContentMode(WebSettings.MIXED_CONTENT_NEVER_ALLOW);
        s.setCacheMode(WebSettings.LOAD_DEFAULT);
        s.setJavaScriptCanOpenWindowsAutomatically(false);
        s.setSupportMultipleWindows(false);
        CookieManager.getInstance().setAcceptCookie(true);
        CookieManager.getInstance().setAcceptThirdPartyCookies(w,true);

        w.addJavascriptInterface(new Bridge(), "MarsadNative");

        w.setWebViewClient(new WebViewClient() {
            @Override public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest req) {
                Uri u = req.getUrl();
                String scheme = u.getScheme();
                if ("https".equalsIgnoreCase(scheme)) return false; // allows Auth0 HTTPS redirect flow
                if ("mailto".equalsIgnoreCase(scheme) || "tel".equalsIgnoreCase(scheme)) {
                    try { startActivity(new Intent(Intent.ACTION_VIEW,u)); } catch(Exception ignored) {}
                }
                return true;
            }
            @Override public void onReceivedSslError(WebView view, android.webkit.SslErrorHandler handler,
                                                     android.net.http.SslError error) {
                handler.cancel();
                Toast.makeText(MainActivity.this,
                    "شهادة الخادم غير موثوقة. ثبّت شهادة الدائرة الصحيحة ولا تتجاوز التحذير.",
                    Toast.LENGTH_LONG).show();
            }
            @Override public void onPageFinished(WebView view, String url) {
                CookieManager.getInstance().flush();
            }
        });

        w.setWebChromeClient(new WebChromeClient() {
            @Override public boolean onShowFileChooser(WebView v, ValueCallback<Uri[]> callback,
                                                        FileChooserParams params) {
                if (chooser != null) chooser.onReceiveValue(null);
                chooser = callback;
                Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT);
                i.setType("*/*");
                i.addCategory(Intent.CATEGORY_OPENABLE);
                try { startActivityForResult(i,71); }
                catch(Exception e) { chooser.onReceiveValue(null); chooser=null; }
                return true;
            }
        });
    }

    public class Bridge {
        @JavascriptInterface public void saveFile(String name, String encoded, String mime) {
            runOnUiThread(() -> {
                try {
                    if (encoded == null || encoded.length() > 50_000_000) return;
                    saveDocument(Base64.decode(encoded,Base64.DEFAULT),
                        name == null || name.isEmpty() ? "marsad-file" : name,
                        mime == null || mime.isEmpty() ? "application/octet-stream" : mime);
                } catch(Exception e) {
                    Toast.makeText(MainActivity.this,"تعذر حفظ الملف",Toast.LENGTH_LONG).show();
                }
            });
        }
        @JavascriptInterface public void print() {
            runOnUiThread(() -> {
                PrintManager pm=(PrintManager)getSystemService(PRINT_SERVICE);
                pm.print("مرصد المشاريع",web.createPrintDocumentAdapter("تقرير مرصد"),
                    new PrintAttributes.Builder().build());
            });
        }
        @JavascriptInterface public String platform() { return "Android"; }
    }

    private void saveDocument(byte[] bytes,String name,String mime) {
        if (pendingFile != null) return;
        pendingFile = bytes;
        try {
            Intent i = new Intent(Intent.ACTION_CREATE_DOCUMENT);
            i.addCategory(Intent.CATEGORY_OPENABLE);
            i.setType(mime);
            i.putExtra(Intent.EXTRA_TITLE,name);
            startActivityForResult(i,72);
        } catch(Exception e) {
            pendingFile = null;
            Toast.makeText(this,"تعذر فتح نافذة الحفظ",Toast.LENGTH_LONG).show();
        }
    }

    @Override protected void onActivityResult(int request,int result,Intent intent) {
        super.onActivityResult(request,result,intent);
        if(request==71 && chooser!=null) {
            chooser.onReceiveValue(result==RESULT_OK && intent!=null && intent.getData()!=null
                ? new Uri[]{intent.getData()} : null);
            chooser=null;
        }
        if(request==72) {
            try {
                if(result==RESULT_OK && intent!=null && intent.getData()!=null && pendingFile!=null) {
                    try(OutputStream out=getContentResolver().openOutputStream(intent.getData())) {
                        out.write(pendingFile);
                    }
                    Toast.makeText(this,"تم حفظ الملف",Toast.LENGTH_SHORT).show();
                }
            } catch(Exception e) {
                Toast.makeText(this,"تعذر حفظ الملف",Toast.LENGTH_LONG).show();
            } finally { pendingFile=null; }
        }
    }

    @Override public void onBackPressed() {
        if(web != null && web.canGoBack()) web.goBack();
        else super.onBackPressed();
    }
}
